package com.miniproject.pg_accommodation_system.controller;

import com.miniproject.pg_accommodation_system.dto.DtoMapper;
import com.miniproject.pg_accommodation_system.dto.OwnerDTO;
import com.miniproject.pg_accommodation_system.dto.PGPlaceDTO;
import com.miniproject.pg_accommodation_system.entity.PGPlace;
import com.miniproject.pg_accommodation_system.exception.ForbiddenException;
import com.miniproject.pg_accommodation_system.service.TenantService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/pg")
@Tag(name = "Tenant/Public APIs", description = "Endpoints accessible to tenants and public users")
public class PGController {

    private final TenantService tenantService;

    public PGController(TenantService tenantService) {
        this.tenantService = tenantService;
    }

    @Operation(summary = "Retrieve PGs by city ID")
    @GetMapping("/city/{cityId}")
    public List<PGPlaceDTO> getPlacesByCity(@PathVariable Long cityId) {
        return tenantService.listByCityId(cityId)
                .stream().map(DtoMapper::toDto).collect(Collectors.toList());
    }

    @Operation(summary = "Retrieve PGs by locality name")
    @GetMapping("/locality/{localityName}")
    public List<PGPlaceDTO> getPlacesByLocality(@PathVariable String localityName) {
        return tenantService.searchByLocality(localityName)
                .stream().map(DtoMapper::toDto).collect(Collectors.toList());
    }

    @Operation(summary = "Retrieve PG place details by ID")
    @GetMapping("/details/{id}")
    public PGPlaceDTO getPlaceDetails(@PathVariable Long id) {
        PGPlace place = tenantService.getPlaceProfile(id, true);
        return DtoMapper.toDto(place);
    }

    @Operation(summary = "Retrieve owner contact for a PG if AVAILABLE")
    @GetMapping("/owner/{id}")
    public OwnerDTO getOwnerContact(@PathVariable Long id) {
        return tenantService.getOwnerContactIfAvailable(id)
                .map(owner -> new OwnerDTO(owner.getId(), owner.getName(), owner.getEmail(), owner.getMobile(), owner.getAge()))
                .orElseThrow(() -> new ForbiddenException("Contact details accessible only if the place is AVAILABLE"));
    }
}
