package com.miniproject.pg_accommodation_system.service.impl;

import com.miniproject.pg_accommodation_system.entity.City;
import com.miniproject.pg_accommodation_system.entity.Locality;
import com.miniproject.pg_accommodation_system.exception.NotFoundException;
import com.miniproject.pg_accommodation_system.repository.CityRepository;
import com.miniproject.pg_accommodation_system.repository.LocalityRepository;
import com.miniproject.pg_accommodation_system.repository.PGPlaceRepository;
import com.miniproject.pg_accommodation_system.service.AdminService;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {

    private final CityRepository cityRepo;
    private final LocalityRepository localityRepo;
    private final PGPlaceRepository placeRepo;

    public AdminServiceImpl(CityRepository cityRepo, LocalityRepository localityRepo, PGPlaceRepository placeRepo) {
        this.cityRepo = cityRepo;
        this.localityRepo = localityRepo;
        this.placeRepo = placeRepo;
    }

    @Override
    public City addCity(String name) {
        City city = new City();
        city.setName(name);
        return cityRepo.save(city);
    }

    @Override
    public Locality addLocality(Long cityId, String name) {
        City city = cityRepo.findById(cityId)
                .orElseThrow(() -> new NotFoundException("City not found with id " + cityId));
        Locality locality = new Locality();
        locality.setName(name);
        locality.setCity(city);
        return localityRepo.save(locality);
    }

   
}
