package com.miniproject.pg_accommodation_system.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PGPlaceDTO {
    private Long id;
    private String registrationNumber;
    private String title;
    private BigDecimal builtUpArea;
    private BigDecimal rentAmount;
    private String status;
    private String address;
    private Integer visitorCount;
    private String cityName;
    private String localityName;
    private String ownerName;
    private String ownerEmail;
    private String ownerMobile;
}
