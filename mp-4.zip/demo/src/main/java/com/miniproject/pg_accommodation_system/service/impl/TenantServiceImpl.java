package com.miniproject.pg_accommodation_system.service.impl;

import com.miniproject.pg_accommodation_system.entity.Owner;
import com.miniproject.pg_accommodation_system.entity.PGPlace;
import com.miniproject.pg_accommodation_system.entity.Status;
import com.miniproject.pg_accommodation_system.exception.ForbiddenException;
import com.miniproject.pg_accommodation_system.exception.NotFoundException;
import com.miniproject.pg_accommodation_system.exception.ValidationException;
import com.miniproject.pg_accommodation_system.repository.PGPlaceRepository;
import com.miniproject.pg_accommodation_system.service.TenantService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class TenantServiceImpl implements TenantService {

    private final PGPlaceRepository placeRepo;

    public TenantServiceImpl(PGPlaceRepository placeRepo) {
        this.placeRepo = placeRepo;
    }

    @Override
    public List<PGPlace> listByCityId(Long cityId) {
        // ✅ Uses cityId and Status enum
        return placeRepo.findByCity_IdAndStatus(cityId, Status.AVAILABLE);
    }

    @Override
    public List<PGPlace> searchByLocality(String locality) {
        if (locality == null || locality.trim().isEmpty()) {
            throw new ValidationException("Locality must be a non-empty text input");
        }
        // ✅ Correct repository method: Locality.name (String)
        return placeRepo.findByLocality_NameAndStatus(locality.trim().toLowerCase(), Status.AVAILABLE);
    }

    @Override
    @Transactional
    public PGPlace getPlaceProfile(Long placeId, boolean includeRelations) {
        PGPlace place = placeRepo.findById(placeId)
                .orElseThrow(() -> new NotFoundException("PG place not found with id " + placeId));

        // ✅ Increment visitor count when details are viewed
        place.setVisitorCount(place.getVisitorCount() == null ? 1 : place.getVisitorCount() + 1);
        return placeRepo.save(place);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Owner> getOwnerContactIfAvailable(Long placeId) {
        PGPlace place = placeRepo.findById(placeId)
                .orElseThrow(() -> new NotFoundException("PG place not found with id " + placeId));

        if (place.getStatus() == Status.AVAILABLE) {
            // ✅ Access owner inside transaction to avoid LazyInitializationException
            return Optional.ofNullable(place.getOwner());
        }
        throw new ForbiddenException("Contact details accessible only if the place is AVAILABLE");
    }
}
