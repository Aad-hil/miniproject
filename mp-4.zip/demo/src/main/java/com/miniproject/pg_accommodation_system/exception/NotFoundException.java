package com.miniproject.pg_accommodation_system.exception;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) { super(message); }
}
