package com.miniproject.pg_accommodation_system.dto;

import com.miniproject.pg_accommodation_system.entity.PGPlace;

public class DtoMapper {

    public static PGPlaceDTO toDto(PGPlace place) {
        PGPlaceDTO dto = new PGPlaceDTO();
        dto.setId(place.getId());
        dto.setRegistrationNumber(place.getRegistrationNumber());
        dto.setTitle(place.getTitle());
        dto.setBuiltUpArea(place.getBuiltUpArea());
        dto.setRentAmount(place.getRentAmount());
        dto.setStatus(place.getStatus() != null ? place.getStatus().name() : null);
        dto.setAddress(place.getAddress());
        dto.setVisitorCount(place.getVisitorCount());

        if (place.getCity() != null) dto.setCityName(place.getCity().getName());
        if (place.getLocality() != null) dto.setLocalityName(place.getLocality().getName());
        if (place.getOwner() != null) {
            dto.setOwnerName(place.getOwner().getName());
            dto.setOwnerEmail(place.getOwner().getEmail());
            dto.setOwnerMobile(place.getOwner().getMobile());
        }
        return dto;
    }
}
