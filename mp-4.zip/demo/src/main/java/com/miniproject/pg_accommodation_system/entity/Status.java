package com.miniproject.pg_accommodation_system.entity;

public enum Status {
    AVAILABLE,
    NOT_AVAILABLE
}
