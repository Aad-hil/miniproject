package com.miniproject.pg_accommodation_system.service;

import com.miniproject.pg_accommodation_system.entity.PGPlace;

import java.util.List;

public interface OwnerService {
    PGPlace addPlace(Long ownerId, PGPlace place, Long cityId, String localityName);
    List<PGPlace> listOwnerPlaces(Long ownerId);
    PGPlace changeAvailability(Long ownerId, Long placeId, String status); // "AVAILABLE" | "NOT_AVAILABLE"
    PGPlace updatePlace(Long ownerId, Long placeId, PGPlace updates);
    void deletePlace(Long ownerId, Long placeId);
    void deletePlace(Long placeId);
}
