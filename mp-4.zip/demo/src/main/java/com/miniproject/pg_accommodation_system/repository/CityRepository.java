package com.miniproject.pg_accommodation_system.repository;

import com.miniproject.pg_accommodation_system.entity.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CityRepository extends JpaRepository<City, Long> {
}
