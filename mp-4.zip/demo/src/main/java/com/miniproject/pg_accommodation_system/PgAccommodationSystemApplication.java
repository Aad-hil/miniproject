package com.miniproject.pg_accommodation_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgAccommodationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgAccommodationSystemApplication.class, args);
	}

}
