package com.miniproject.pg_accommodation_system.repository;

import com.miniproject.pg_accommodation_system.entity.PGPlace;
import com.miniproject.pg_accommodation_system.entity.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PGPlaceRepository extends JpaRepository<PGPlace, Long> {
    List<PGPlace> findByCity_IdAndStatus(Long cityId, Status status);
    List<PGPlace> findByLocality_NameAndStatus(String localityName, Status status);
    List<PGPlace> findByOwner_Id(Long ownerId);
}
