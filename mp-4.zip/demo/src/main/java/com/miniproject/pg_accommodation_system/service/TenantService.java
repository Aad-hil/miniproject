package com.miniproject.pg_accommodation_system.service;

import com.miniproject.pg_accommodation_system.entity.Owner;
import com.miniproject.pg_accommodation_system.entity.PGPlace;

import java.util.List;
import java.util.Optional;

public interface TenantService {
    List<PGPlace> listByCityId(Long cityId);
    List<PGPlace> searchByLocality(String localityName);
    PGPlace getPlaceProfile(Long placeId, boolean includeRelations);
    Optional<Owner> getOwnerContactIfAvailable(Long placeId);
}
