export interface UserHealthData {
  age: number;
  earnings: number;
  hasPreExistingConditions: boolean;
  isSmoker: boolean;
  hasChronicDiseases: boolean;
  exerciseRegularly: boolean;
}